import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignUpCustomerComponent } from './sign-up-customer/sign-up-customer.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';
import { HttpClientModule } from '@angular/common/http';
import { MerchantloginComponent } from './merchantlogin/merchantlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
@NgModule({
  declarations: [
    AppComponent,
    SignUpCustomerComponent,
    WelcomeComponent,
    SignUpMerchantComponent,
    MerchantloginComponent,
    AdminloginComponent,
    CustomerloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
