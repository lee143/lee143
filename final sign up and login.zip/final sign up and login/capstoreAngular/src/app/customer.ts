export class Customer {
    emailId:String;
    firstName:String;
    lastName:String;
    isValid:String;
    address:String;
    phoneNo:String;
    walletBalance:number;
    
}
