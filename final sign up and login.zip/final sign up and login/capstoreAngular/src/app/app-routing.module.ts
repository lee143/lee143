import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignUpCustomerComponent } from './sign-up-customer/sign-up-customer.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { MerchantloginComponent } from './merchantlogin/merchantlogin.component';


const routes: Routes = [
  {
    path:'customerSignup',
    component: SignUpCustomerComponent
  },
  {
    path:'merchantSignup',
    component:SignUpMerchantComponent
  },
 
     {
    path:'adminlogin',
      component:AdminloginComponent
     },
     {
       path:'customerlogin',
       component:CustomerloginComponent
     },
     {
       path:'merchantlogin',
       component:MerchantloginComponent
     },
     {
       path: 'welcome',
       component: WelcomeComponent
     },
     {
    path:'',redirectTo :'welcome',pathMatch:'full'
     }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
