import { Component, OnInit } from '@angular/core';
import { CapServiceService } from '../cap-service.service';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {

  constructor(private capService: CapServiceService) { }

  ngOnInit() {
  }

  loginCustomer(custEmail: string,password: string) {
       this.capService.loginCustomer(custEmail,password).subscribe((customer) => {
          console.log(customer)
       })
  }


}
