import { Component, OnInit } from '@angular/core';
import { CapServiceService } from '../cap-service.service';

@Component({
  selector: 'app-merchantlogin',
  templateUrl: './merchantlogin.component.html',
  styleUrls: ['./merchantlogin.component.css']
})
export class MerchantloginComponent implements OnInit {

  constructor(private capService: CapServiceService) { }

  ngOnInit() {
  }

  loginMerchant(merchEmail: string,password: string) {
    this.capService.loginMerchant(merchEmail,password).subscribe((merchant) => {
      console.log(merchant)
   })
  }
}
