import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CapServiceService } from '../cap-service.service';

@Component({
  selector: 'app-sign-up-customer',
  templateUrl: './sign-up-customer.component.html',
  styleUrls: ['./sign-up-customer.component.css']
})
export class SignUpCustomerComponent implements OnInit {
  customer:Customer;
  constructor(private capService:CapServiceService) { }

  ngOnInit() {
  }
  addCustomer(firstName:String,lastName:String,emailId:String,password:string,address:string,phone:number){
    this.customer=new Customer(emailId,firstName,lastName,address,phone)
    console.log(this.customer);
    this.capService.addCustomer(this.customer,password).subscribe();

  }
}
