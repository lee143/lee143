import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-merchant',
  templateUrl: './sign-up-merchant.component.html',
  styleUrls: ['./sign-up-merchant.component.css']
})
export class SignUpMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
