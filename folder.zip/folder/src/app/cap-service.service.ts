import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CapServiceService {
  private url: string;
  constructor(private http: HttpClient) {}

 
 public addCustomer(customer:Customer,password:String): Observable<Customer>
 {
 return this.http.post<Customer>('http://localhost:9998/register/customer/'+password,customer)
 }                                                         



}