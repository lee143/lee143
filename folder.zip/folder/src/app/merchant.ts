export class Merchant {
    emailId:String
    panCard:number
    isValid:String
    firstName:String
    lastName:String
    address:String
    phoneNo:number
    merType:String
    

}
