import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignUpCustomerComponent } from './sign-up-customer/sign-up-customer.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';
import { WelcomeComponent } from './welcome/welcome.component';


const routes: Routes = [
  {
    path:'customerSignup',
    component: SignUpCustomerComponent
  },
  {
    path:'merchantSignup',
    component:SignUpMerchantComponent
  },
  {
    path:'welcome',
    component:WelcomeComponent
  },
  {
    path:'',
    component:WelcomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
