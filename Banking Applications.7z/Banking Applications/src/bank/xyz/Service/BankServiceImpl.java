package bank.xyz.Service;

import java.util.List;
import java.util.Scanner;

import bank.xyz.Dao.Dao;
import bank.xyz.Dao.DaoImpl;
import bank.xyz.Model.Bank;
import bank.xyz.Validation.Validation;


public class BankServiceImpl implements BankService {
	private Dao dao = new DaoImpl();
	private Scanner sc = new Scanner(System.in);
	
	/*
	 * This method is for creating a Account
	 */
	@Override
	public void createAccount() {
		 Bank b = new Bank();
		     System.out.println("\nEnter your details to creat account :");
		     System.out.println("Enter username");
		     b.setUserName(sc.next());
		     if(Validation.userNameValidation(b.getUserName()))
		     {
		     b.setAccNo();
		     b.setBalance();
		     dao.createAccount(b);
		     }
	}
	
	/*
	 * This method is for Show Balance
	 */
	
	@Override
	public Bank showBalance() {
		System.out.println("Enter your account number :");
		int accNo = sc.nextInt();
		Validation.acccountValidation(accNo);
		return dao.showBalance(accNo);
	}
	
	/*
	 * This methosd is for Deposit
	 */
	@Override
	public void deposit() {
		System.out.println("Enter the account number :");
		int accNo = sc.nextInt();
		Validation.acccountValidation(accNo);
		System.out.println("Enter Deposited Amount :");
		int amt = sc.nextInt();
		dao.deposit(accNo,amt);
		}
	
	/*
	 * This method is for with draw amount
	 */
	
	@Override
	public void withdraw() {
		System.out.println("Enter the Account number :");
		int accNo = sc.nextInt();
		Validation.acccountValidation(accNo);
		System.out.println("Enter Withdraw Amount :");
		int amt = sc.nextInt();
		dao.withdraw(accNo,amt);
		}
	
	/*
	 * This method is for Fund transfer
	 */
	
	@Override
	public void fundTransfer() {
		System.out.println("Enter Account Number");
		int accNo = sc.nextInt();
		Validation.acccountValidation(accNo);
		System.out.println("Enter Account number to be Transferred");
		int accNoto = sc.nextInt();
		Validation.acccountValidation(accNo);
		System.out.println("Enter amount to be transferred");
		int amt = sc.nextInt();
		dao.fundTransfer(accNo,accNoto,amt);
		}
	
	/*
	 * Thjs method is for Print Transaction
	 */
	
	@Override
	public List<String> printTrans() {
		int accNO;
		String pass;
		System.out.println("Enter Your Account No");
		accNO=sc.nextInt();
		return(dao.printTrans1(accNO));		
	}
	
}
