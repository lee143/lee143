package com.capg.service;

import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.capg.bean.Credential;
import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.Product;
import com.capg.bean.WishItem;
import com.capg.dao.CapgCustomerRepo;
import com.capg.dao.CapgMerchantRepo;
import com.capg.dao.CapgProductRepo;
import com.capg.dao.CapgWishItemRepo;
import com.capg.dao.CredentialsDao;

@Service
public class CapgService {
	
	
	@Autowired CredentialsDao credentialDao;
	@Autowired CapgCustomerRepo customerRepo;
	@Autowired CapgWishItemRepo customerWishRepo;
	@Autowired CapgMerchantRepo merchantRepo;
	@Autowired CapgProductRepo productRepo;
	Product product;
	public void registerCustomer(Customer customer, String password) {
		Credential cred = new Credential();
		customerRepo.save(customer);
		cred.setId(customer.getCustId());
		cred.setPassword(password);
		credentialDao.save(cred);
	}
	
	public Customer findCustomerById(String custId) {  
		return customerRepo.findById(custId).get();
	}
	public void addCustomerWish(String custId,WishItem wish) {
		Customer customer = findCustomerById(custId);
		List<WishItem> wishList = customer.getWishItems();
		wishList.add(wish);
		customer.setWishItems(wishList);
		customerWishRepo.save(wish);
		customerRepo.save(customer);
	}

	public void registerMerchant(Merchant merchant,String password) {
		Credential cred = new Credential();
		merchantRepo.save(merchant);
		cred.setId(merchant.getMerId());
		cred.setPassword(password);
		credentialDao.save(cred);
	}

	public Customer loginCustomer(String email, String password) throws RuntimeException{
		Customer loginCustomer = null;
		/*
		 * try { String loginCustomerId = customerRepo.getCustId(email);
		 * if(loginCustomerId == null || loginCustomerId.length() == 0) { throw new
		 * RuntimeException("Customer with email not found"); } loginCustomer =
		 * customerRepo.findById(loginCustomerId).get(); return loginCustomer; }
		 * catch(Exception ex) { throw new RuntimeException(ex.getMessage()); }
		 */
		try {
			loginCustomer = customerRepo.getCustomerByEmail(email);
			if(credentialDao.getPasswordById(loginCustomer.getCustId()).equals(password)) {
				return loginCustomer;
			}
			else {
				throw new RuntimeException("Password Incorrect");
			}
		}
		catch(Error ex) {
			throw new RuntimeErrorException(ex, ex.getMessage());
		}
	}
	
	public Merchant loginMerchant(String email, String password) throws RuntimeException{
		Merchant loginMerchant = null;
		/*
		 * try { String loginCustomerId = customerRepo.getCustId(email);
		 * if(loginCustomerId == null || loginCustomerId.length() == 0) { throw new
		 * RuntimeException("Customer with email not found"); } loginCustomer =
		 * customerRepo.findById(loginCustomerId).get(); return loginCustomer; }
		 * catch(Exception ex) { throw new RuntimeException(ex.getMessage()); }
		 */
		try {
			loginMerchant = merchantRepo.getMerchantByEmail(email);
			if(credentialDao.getPasswordById(loginMerchant.getMerId()).equals(password)) {
				return loginMerchant;
			}
			else {
				throw new RuntimeException("Password Incorrect");
			}
		}
		catch(Error ex) {
			throw new RuntimeErrorException(ex, ex.getMessage());
		}
	}
	
	public Product addMerchantProduct( Product product) {
		return productRepo.save(product);
	}
	
	
	public List<Product> getMerchantProductsById(String mid){
			return productRepo.getMerchantProductsById(mid);	
	}
	
	/*
	 * public boolean updateMerchantProduct(String mid, String pid) throws
	 * RuntimeException{ product = productRepo.getProductById(mid, pid);
	 * 
	 * }
	 */
	
	
	
	
	}

