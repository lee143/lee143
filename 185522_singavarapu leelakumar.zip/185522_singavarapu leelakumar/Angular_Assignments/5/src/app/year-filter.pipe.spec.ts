import { YearFilterPipe } from './year-filter.pipe';

describe('YearFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new YearFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
