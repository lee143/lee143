export class Book{
code:number;
name:string;
author:string;
genre:string;
}