import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { HttpClient} from '@angular/common/http';
import { Book } from '../Book';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  bookList:any=[];
  constructor(private bookService:BookService) { 
  this.bookList= this.bookService.bookList;
   
  }
  
  ngOnInit() {
    this.bookList= this.bookService.bookList;
    
  }
  reload(){
    this.bookList= this.bookService.bookList;
  }

  flag=false;
name;id;price;category;

bo:Book=new Book;
  changeFlag(b:Book){
    this.flag=true;
    this.name=b.name;this.id=b.id;this.price=b.price;this.category=b.category;
    

  }


  delete(id:number){
    this.bookService.deleteBook(id);
    this.bookList= this.bookService.bookList;
  }
}
