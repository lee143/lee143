export class Book{
    id:number;
    name:string;
    price:string;
    category:string;
    }